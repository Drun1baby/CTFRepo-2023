/*    */ package BOOT-INF.classes.com.yancao.ctf;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.boot.autoconfigure.SpringBootApplication;
/*    */ 
/*    */ @SpringBootApplication
/*    */ public class YancaoCtfJavaApplication {
/*    */   public static void main(String[] args) {
/* 10 */     SpringApplication.run(com.yancao.ctf.YancaoCtfJavaApplication.class, args);
/*    */   }
/*    */ }


/* Location:              G:\OneDrive备份\Repo\CTF-Repo-2023-Two\2023 巅峰极客\ctf-0.0.1-SNAPSHOT.jar!\BOOT-INF\classes\com\yancao\ctf\YancaoCtfJavaApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */