/**
 * Support package for the Java {@link java.util.ServiceLoader} facility.
 */
@NonNullApi
@NonNullFields
package org.springframework.beans.factory.serviceloader;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
