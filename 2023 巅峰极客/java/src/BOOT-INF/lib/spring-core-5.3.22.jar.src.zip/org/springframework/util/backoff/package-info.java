/**
 * A generic back-off abstraction.
 */
@NonNullApi
@NonNullFields
package org.springframework.util.backoff;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
