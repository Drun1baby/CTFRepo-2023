/**
 * Useful generic {@code java.util.function} helper classes.
 */
@NonNullApi
@NonNullFields
package org.springframework.util.function;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
