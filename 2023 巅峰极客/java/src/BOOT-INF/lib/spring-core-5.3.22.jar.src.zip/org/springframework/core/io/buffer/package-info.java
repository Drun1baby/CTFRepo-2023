/**
 * Generic abstraction for working with byte buffer implementations.
 */
@NonNullApi
@NonNullFields
package org.springframework.core.io.buffer;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
