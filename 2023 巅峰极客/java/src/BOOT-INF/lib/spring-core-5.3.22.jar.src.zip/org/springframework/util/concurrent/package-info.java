/**
 * Useful generic {@code java.util.concurrent.Future} extensions.
 */
@NonNullApi
@NonNullFields
package org.springframework.util.concurrent;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
