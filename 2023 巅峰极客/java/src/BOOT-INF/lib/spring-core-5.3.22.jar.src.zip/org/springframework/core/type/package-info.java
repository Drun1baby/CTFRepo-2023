/**
 * Core support package for type introspection.
 */
@NonNullApi
@NonNullFields
package org.springframework.core.type;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
