/**
 * Support package for reading and managing the components index.
 */
@NonNullApi
@NonNullFields
package org.springframework.context.index;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
