/**
 * Support for class instrumentation on BEA WebLogic 10+.
 */
@NonNullApi
@NonNullFields
package org.springframework.instrument.classloading.weblogic;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
