/**
 * Formatters for {@code java.util.Date} properties.
 */
@NonNullApi
@NonNullFields
package org.springframework.format.datetime;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
