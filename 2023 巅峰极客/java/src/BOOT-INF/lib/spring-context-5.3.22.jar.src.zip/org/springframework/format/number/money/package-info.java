/**
 * Integration with the JSR-354 <code>javax.money</code> package.
 */
@NonNullApi
@NonNullFields
package org.springframework.format.number.money;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
