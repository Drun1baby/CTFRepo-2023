/**
 * SpEL's default implementations for various core abstractions.
 */
@NonNullApi
@NonNullFields
package org.springframework.expression.spel.support;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
