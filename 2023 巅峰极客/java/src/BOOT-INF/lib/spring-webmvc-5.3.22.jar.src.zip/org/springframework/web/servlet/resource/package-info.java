/**
 * Support classes for serving static resources.
 */
@NonNullApi
@NonNullFields
package org.springframework.web.servlet.resource;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
