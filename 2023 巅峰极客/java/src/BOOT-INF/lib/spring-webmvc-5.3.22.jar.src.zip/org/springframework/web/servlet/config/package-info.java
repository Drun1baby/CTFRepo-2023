/**
 * Defines the XML configuration namespace for Spring MVC.
 */
@NonNullApi
@NonNullFields
package org.springframework.web.servlet.config;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
