/**
 * XML encoder and decoder support.
 */
@NonNullApi
@NonNullFields
package org.springframework.http.codec.xml;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
