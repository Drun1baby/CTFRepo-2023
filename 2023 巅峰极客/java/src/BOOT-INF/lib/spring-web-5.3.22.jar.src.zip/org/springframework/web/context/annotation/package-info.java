/**
 * Provides convenience annotations for web scopes.
 */
@NonNullApi
@NonNullFields
package org.springframework.web.context.annotation;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
